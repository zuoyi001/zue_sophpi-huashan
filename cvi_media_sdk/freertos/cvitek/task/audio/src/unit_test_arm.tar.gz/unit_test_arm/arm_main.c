
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <string.h>
#include "ssp_unit_test.h"
#include "cvi_sys.h"

#ifndef CVIAUDIO_CALLOC
#define CVIAUDIO_CALLOC(TYPE, COUNT) ((TYPE *)calloc(COUNT, sizeof(TYPE)))
#endif

int main(int argc, char *const argv[])
{
	argc = argc;
	argv = argv;

	printf("Enter arm test of ssp_main.c...\n");
	CVI_U64 u64PhyAddr = 0;
	CVI_VOID *pVirAddr = CVIAUDIO_CALLOC(short, 160);
	CVI_S32 s32Ret = 0;
	FILE *fd_user;
	printf("[%s][%d]\n", __func__, __LINE__);
	printf("[%s][%d]\n", __func__, __LINE__);


	fd_user = fopen("/tmp/user_arm.raw", "wb");
	if (!fd_user) {
		printf("[%s][%d]error\n", __func__, __LINE__);
		return 0;
	}
	//same as rtos function
	SSP_Algorithm_Init();
	int ret = 1;

	while (ret) {
		//same as rtos function
		ret = SSP_Algorithm(1, NULL, &pVirAddr);
		if (ret == 0) {
			printf("TestFinished ...force break!!\n");
			break;
		}

		fwrite(pVirAddr, 1, 320, fd_user);
	}
	printf("leaving   ...do the file close\n");
	fclose(fd_user);
	return 0;
}